import network, time, uasyncio as asyncio
from microws import MicroWS

SSID = "Keenetic-2432"
PASSWORD = "iAQTYhK9"
SERVER_IP = "192.168.1.6"
SERVER_PORT = 8080
PATH = "/"

def wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        wlan.connect(SSID, PASSWORD)
        for _ in range(100):
            if wlan.isconnected(): break
            time.sleep(0.1)
    if not wlan.isconnected():
        raise RuntimeError("WiFi yok")
    print("WiFi:", wlan.ifconfig())

async def on_message(msg):
    print("RX:", msg)

async def on_open():
    print("OPEN")

async def on_close():
    print("CLOSE")

async def on_error(e):
    print("ERR:", e)

async def app():
    wifi()
    ws = MicroWS(SERVER_IP, SERVER_PORT, PATH, reconnect=True, heartbeat_s=15)
    asyncio.create_task(ws.start(on_message=on_message, on_open=on_open, on_close=on_close, on_error=on_error))
    await ws.send("Hello from lib!")
    await ws.send_json({"type":"hello","t":time.time()})
    i = 0
    while True:
        i += 1
        await asyncio.sleep(3)
        await ws.send("tick {}".format(i))
        if i % 5 == 0:
            await ws.send_json({"type":"tick","i":i})

asyncio.run(app())
