[handlers.py]

class DeviceHandlers:
    ...
    def setLedColor(self, r, g, b):
        if hasattr(self, 'led'):
            self.led.set_color(r, g, b)

    def readRfidCard(self):
        if hasattr(self, 'rfid'):
            return self.rfid.read_card()
        return None