[dev_rasppico.py]

class RGBLED:
    def __init__(self, pin, count=1):
        import neopixel
        import board
        self.leds = neopixel.NeoPixel(getattr(board, pin), count, brightness=0.3, auto_write=True)
        self.count = count
        self.off()

    def set_color(self, r, g, b):
        for i in range(self.count):
            self.leds[i] = (r, g, b)

    def off(self):
        self.set_color(0, 0, 0)

class RFID:
    def __init__(self):
        import busio, digitalio, board
        from adafruit_mfrc522 import MFRC522

        spi = busio.SPI(board.GP10, board.GP11, board.GP12)
        cs = digitalio.DigitalInOut(board.GP13)
        self.reader = MFRC522(spi, cs)

    def read_card(self):
        uid = self.reader.read_passive_target(timeout=0.5)
        if uid:
            return [hex(x) for x in uid]
        return None